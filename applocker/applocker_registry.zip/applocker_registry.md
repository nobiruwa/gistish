<https://www.microsoftpressstore.com/articles/article.aspx?p=2228450&seqNum=11>
<https://docs.microsoft.com/en-us/windows/security/threat-protection/windows-defender-application-control/applocker/applocker-settings>
